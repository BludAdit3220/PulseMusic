/**
 * PulseMusic Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.pulsemusic.music.ui.component

enum class LyricsBackgroundStyle {
    SOLID, BLUR, GRADIENT
}
